import { Fragment } from 'react';

import Cart from './components/Cart/Cart';
import Header from "./components/Layout/Header";
import Meals from "./components/Meals/Meals";
import MealsSummary from "./components/Meals/MealsSummary";

function App() {
  return (
    <Fragment>
      <Cart />
      <Header />
      <main>
        <Meals />
        <MealsSummary />
      </main>
    </Fragment>
  );
}

export default App;